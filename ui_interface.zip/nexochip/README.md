# NexoChip Website Clone

This folder contains a static mirror of `https://nexochip.com/` (HTML/CSS/JS/assets).

## Run locally

From this folder:

```powershell
python -m http.server 4173
```

Then open:

- `http://127.0.0.1:4173/`
- `http://127.0.0.1:4173/services/`
- `http://127.0.0.1:4173/about/`
- `http://127.0.0.1:4173/contact/`

## Notes

- Built from the current live production bundles and assets.
- Routes are mirrored with folders so direct links load correctly on simple static hosting.